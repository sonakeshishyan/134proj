# 134proj

References:
https://www.w3schools.com/css/css3_buttons.asp
https://www.w3schools.com/css/css_link.asp
https://www.youtube.com/watch?v=sNXfI3woBEw&ab_channel=JohnKomarnicki
https://www.w3schools.com/css/css3_buttons.asp
https://www.w3schools.com/howto/howto_css_searchbar.asp
https://www.w3schools.com/howto/howto_css_rounded_images.asp
https://fonts.google.com/icons?selected=Material+Symbols+Outlined:add_circle:FILL@0;wght@400;GRAD@0;opsz@24&icon.size=24&icon.color=%235f6368
https://stackoverflow.com/questions/572768/styling-an-input-type-file-button
https://www.w3schools.com/tags/tag_progress.asp
https://forum.freecodecamp.org/t/how-do-i-display-elements-in-rows/320909/2
https://sitebulb.com/hints/links/has-link-with-a-url-in-onclick-attribute/
https://www.w3schools.com/js/tryit.asp?filename=trygoogle_chart_line
https://developers.google.com/chart/interactive/docs/gallery/linechart